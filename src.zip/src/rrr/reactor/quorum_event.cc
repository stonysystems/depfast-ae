
#include "quorum_event.h"

namespace janus {

} // namespace janus
