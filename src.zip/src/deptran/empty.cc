/**
 * This empty file is for building purpose. Building systems such as
 * waf and cmake needs a source file to generate a target.
 */
