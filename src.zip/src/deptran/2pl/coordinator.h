#pragma once

#include "deptran/classic/coordinator.h"

namespace janus {

class Coordinator2pl: public CoordinatorClassic {
  using CoordinatorClassic::CoordinatorClassic;
};

} // namespace janus
