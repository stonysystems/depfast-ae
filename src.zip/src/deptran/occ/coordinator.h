#pragma once

#include "deptran/classic/coordinator.h"

namespace janus {

class CoordinatorOcc: public CoordinatorClassic {
  using CoordinatorClassic::CoordinatorClassic;
};

} //namespace janus
