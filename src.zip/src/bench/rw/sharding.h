//
// Created by lamont on 1/4/16.
//
#pragma once
#include <bench/tpcc_real_dist/sharding.h>

namespace janus {
  class RWBenchmarkSharding : public TpccdSharding {
  };
}
